﻿using Bloggie.web.Models.Domain;

namespace Bloggie.web.Repositories
{
    public interface IBlogPostRepository
    {
        // GET all
        Task<IEnumerable<BlogPost>> GetAllAsync();
        // GET by Id
        Task<BlogPost> GetAsync(Guid id);
        // POST Add Blog Post
        Task<BlogPost> AddAsync(BlogPost post);
        // POST Update Blog Post
        Task<BlogPost> UpdateAsync(BlogPost post);
        // DELETE Delete Blog Post
        Task<bool> DeleteAsync(Guid id);

    }
}
