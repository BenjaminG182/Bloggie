﻿
namespace Bloggie.web.Repositories
{
    public class ImageRepositoryCloudinary : IImageRepository
    {
        public Task<string> UploadAsync(IFormFile file)
        {
            
        }
    }
}
